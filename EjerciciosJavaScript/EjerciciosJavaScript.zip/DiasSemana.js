let diasSemana=["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];

let num=prompt("Introduce un número entre 0 y 6:");

console.log("El día correspondiente es: "+ diasSemana[num]);