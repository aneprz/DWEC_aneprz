let lado=5;
let perimetro=lado*4;
let area=lado*lado;
console.log("Área: "+area+", perímetro: "+perimetro);