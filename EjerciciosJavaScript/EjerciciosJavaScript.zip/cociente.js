let num_uno=5;
let num_dos=4;
if (num_dos==0) {
    console.log("Error. No se puede dividir entre 0");
} else{
    let div=num_uno/num_dos;
    console.log("El cociente es ",div);
}