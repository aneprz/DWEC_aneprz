    num_uno=4
    num_dos=8
    if (num_uno > num_dos) {
        dif=num_uno-num_dos
        print("La diferencia es "+dif)
    } else if (num_dos > num_uno) {
        dif=num_dos-num_uno
        print("La diferencia es "+dif)
    }else{
        print("No hay diferencia")
    }