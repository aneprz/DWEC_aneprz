let num_uno=4;
let num_dos=7;
let dif=0;

if (num_uno>num_dos) {
    dif=num_uno-num_dos;
    console.log("Diferencia: ",dif);
} else if(num_dos>num_uno){
    dif=num_dos-num_uno;
    console.log("Diferencia: ",dif);
} else {
    console.log("No hay diferencia");
}