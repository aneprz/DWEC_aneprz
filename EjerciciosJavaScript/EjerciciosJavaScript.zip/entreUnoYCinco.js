let numero;

do {
  numero = prompt("Introduce un número entre 1 y 5:");
} while (numero<1 || numero>5);

alert("Has introducido: "+numero);
