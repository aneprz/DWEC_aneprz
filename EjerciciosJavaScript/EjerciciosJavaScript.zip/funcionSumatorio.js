function sumaLista(lista) {
    let suma=0;
    for (let i=0; i<lista.length; i++) {
        suma=suma+lista[i];
    }
    return suma;
}