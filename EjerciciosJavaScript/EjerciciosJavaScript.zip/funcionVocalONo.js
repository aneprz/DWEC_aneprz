function vocalONo(letra){
    switch (letra) {
        case 'A' || 'a':
            return true;
        case 'E'||'e':
            return true;
        case 'I'||'i':
            return true;
        case 'O'||'o':
            return true;
        case 'U'||'u':
            return true;
        default:
            return false;
    }
}