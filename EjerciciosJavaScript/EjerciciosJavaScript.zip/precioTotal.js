let precioProducto=80;
let iva=20;
let precioTotal=precioProducto+(precioProducto*iva/100);
console.log("El precio total es "+precioTotal);